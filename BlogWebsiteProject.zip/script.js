function addComment(event, commentSectionId) {
    event.preventDefault();
    const form = event.target;
    const name = form.querySelector('input').value;
    const message = form.querySelector('textarea').value;
    const commentBox = document.getElementById(commentSectionId);
    const newComment = document.createElement('div');
    newComment.innerHTML = `<strong>${name}</strong>: ${message}`;
    commentBox.appendChild(newComment);
    form.reset();
}
